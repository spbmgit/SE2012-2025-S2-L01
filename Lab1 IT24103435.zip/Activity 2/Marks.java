import java.util.Scanner;

public class Marks {
    static int[][] marks; // [studentID][subjectID] ? subjectID: 0=Math, 1=Chem, 2=Phys

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = scanner.nextInt();
        marks = new int[n + 1][3]; 

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Add student marks: add [studentID]");
            System.out.println("2. Update student mark: update [studentID] [subjectID]");
            System.out.println("3. Get average for a subject: average_s [subjectID]");
            System.out.println("4. Get average for a student: average [studentID]");
            System.out.println("5. Get total marks of a student: total [studentID]");
            System.out.println("6. Exit");

            System.out.print("Enter command: ");
            String command = scanner.next();

            if (command.equalsIgnoreCase("add")) {
                int studentID = scanner.nextInt();
                if (studentID >= 1 && studentID <= n) {
                    System.out.print("Enter marks for Mathematics: ");
                    marks[studentID][0] = scanner.nextInt();
                    System.out.print("Enter marks for Chemistry: ");
                    marks[studentID][1] = scanner.nextInt();
                    System.out.print("Enter marks for Physics: ");
                    marks[studentID][2] = scanner.nextInt();
                } else {
                    System.out.println("Invalid student ID.");
                }

            } else if (command.equalsIgnoreCase("update")) {
                int studentID = scanner.nextInt();
                int subjectID = scanner.nextInt();
                if (studentID >= 1 && studentID <= n && subjectID >= 1 && subjectID <= 3) {
                    System.out.print("Enter new mark: ");
                    marks[studentID][subjectID - 1] = scanner.nextInt();
                } else {
                    System.out.println("Invalid input.");
                }

            } else if (command.equalsIgnoreCase("average_s")) {
                int subjectID = scanner.nextInt();
                if (subjectID >= 1 && subjectID <= 3) {
                    double sum = 0;
                    for (int i = 1; i <= n; i++) {
                        sum += marks[i][subjectID - 1];
                    }
                    System.out.println("Average for subject " + subjectID + " = " + (sum / n));
                } else {
                    System.out.println("Invalid subject ID.");
                }

            } else if (command.equalsIgnoreCase("average")) {
                int studentID = scanner.nextInt();
                if (studentID >= 1 && studentID <= n) {
                    double sum = marks[studentID][0] + marks[studentID][1] + marks[studentID][2];
                    System.out.println("Average for student " + studentID + " = " + (sum / 3));
                } else {
                    System.out.println("Invalid student ID.");
                }

            } else if (command.equalsIgnoreCase("total")) {
                int studentID = scanner.nextInt();
                if (studentID >= 1 && studentID <= n) {
                    int total = marks[studentID][0] + marks[studentID][1] + marks[studentID][2];
                    System.out.println("Total marks for student " + studentID + " = " + total);
                } else {
                    System.out.println("Invalid student ID.");
                }

            } else if (command.equalsIgnoreCase("6") || command.equalsIgnoreCase("exit")) {
                System.out.println("Exiting program.");
                break;

            } else {
                System.out.println("Invalid command.");
            }
        }

        scanner.close();
    }
}   