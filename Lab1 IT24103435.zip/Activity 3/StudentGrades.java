import java.util.Scanner;

public class StudentGrades {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] studentNames = new String[10];
        int[][] marks = new int[10][10];
        String[][] subjectNames = new String[10][10];
        int[] subjectCounts = new int[10];

        int studentIndex = 0;

        while (true) {
            System.out.print("Enter student name (or type 'stop' to finish): ");
            String name = sc.nextLine();
            if (name.equals("stop")) {
                break;
            }

            studentNames[studentIndex] = name;

            System.out.print("How many subjects for " + name + "? ");
            int subCount = sc.nextInt();
            sc.nextLine();
            subjectCounts[studentIndex] = subCount;

            for (int j = 0; j < subCount; j++) {
                System.out.print("Enter subject name: ");
                subjectNames[studentIndex][j] = sc.nextLine();

                System.out.print("Enter marks for " + subjectNames[studentIndex][j] + ": ");
                marks[studentIndex][j] = sc.nextInt();
                sc.nextLine();
            }

            studentIndex++;
        }

        System.out.print("Type 'grades' to show results: ");
        String command = sc.nextLine();

        if (command.equals("grades")) {
            System.out.println("Showing grades...");
            for (int i = 0; i < studentIndex; i++) {
                System.out.println("Student: " + studentNames[i]);
                for (int j = 0; j < subjectCounts[i]; j++) {
                    int score = marks[i][j];
                    String grade = getGrade(score);
                    System.out.println("Subject: " + subjectNames[i][j]);
                    System.out.println("Marks: " + score);
                    System.out.println("Grade: " + grade);
                    System.out.println("---");
                }
                System.out.println("==============");
            }
        }

        sc.close();
    }

    public static String getGrade(int score) {
        if (score >= 90) return "Grade A";
        else if (score >= 80) return "Grade B";
        else if (score >= 70) return "Grade C";
        else if (score >= 60) return "Grade D";
        else return "Fail";
    }
}
